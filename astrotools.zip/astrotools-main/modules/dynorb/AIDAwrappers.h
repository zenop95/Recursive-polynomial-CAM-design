#ifndef dynorb_AIDAWRAPPERS_H_
#define dynorb_AIDAWRAPPERS_H_

#include <dace/dace.h>
#include "AIDA.h"
#include "astro/AstroCnvRef.h"
#include "DynClass.h"

template<typename T>
class AIDADynamics : public dynamics<T>
{
public:
	AIDADynamics(const std::string& gravmodel_name, const unsigned int gravmodel_order, const int AIDA_flags[3],
		const T& Bfactor, const T& SRPC)
		: m_aidaProp(gravmodel_name, gravmodel_order, AIDA_flags, 78.0), m_eventflag(false)

	{
		//Set uncertain parameters
		m_aidaProp.setUncParam("SRPC", SRPC);
		m_aidaProp.setUncParam("Bfactor", Bfactor);
	}

	DACE::AlgebraicVector<T> evaluate(const DACE::AlgebraicVector<T>& x, double t)
	{
		return m_aidaProp.evaluation(t, x, m_eventflag);
	}

	bool checkEvent()
	{
		return m_eventflag;
	}
private:
	dynorb::AIDA<T> m_aidaProp;
	bool m_eventflag;
};

#endif