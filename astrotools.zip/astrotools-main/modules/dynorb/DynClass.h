#ifndef dynorb_DYNCLASS_H_
#define dynorb_DYNCLASS_H_


#include <dace/dace.h>

// CLASSES

template<typename T, typename U>
class dynamicsTemplateTime
{
public:
	dynamicsTemplateTime() {};
	virtual DACE::AlgebraicVector<T> evaluate(const DACE::AlgebraicVector< T >& x, U t) = 0;
	virtual bool checkEvent()
	{
		return false;
	}
};

template<typename T>
class dynamics : public dynamicsTemplateTime<T, double>
{
public:
	dynamics() {};
};

#endif