/*
 * AstroRoutines.h
 *
 *  Created on: Oct. 20, 2014
 *      Author: Dinamica
 *  Modified on: March 2016
 *      Author: Mauro Massari (mauo.massari@polimi.it)
 */

#ifndef astro_AstroRoutines_H
#define astro_AstroRoutines_H

#include <dace/dace.h>
#include "Reference.h"

namespace astro {


/*! \defgroup TimeConversions Time Conversions
 * @brief Routines dedicated to time transformations.
 *
 * This module groups all routines dedicated to time transformations.
 *
 * Ephemeris time are seconds past J2000 (JD 2451545.0, 1 January 2000, 12:00:00.0)
 * MJD2000 are days past is referred to JD 2451544.5, i.e. mjd2000 = jd - 2451544.5
 *
 * @{
 */

double str2et(const std::string &utc)
{
  /*! Returns the ephemeris time corresponding to a time string.
   * Wrapper of CSPICE function str2et_c.
   * @param[in] utc A formatted string representing time.
   * @return Ephemeris time
   */

  double et;
  str2et_c(utc.c_str(), &et);
  return et;

}

std::string et2str(const double &et, const std::string &FORMAT)
{
  /*! Returns the UTC string corresponding to ephemeris time.
   * Wrapper of CSPICE function timout_c.
    * @param[in] et Ephemeris time
    * @param[in] FORMAT String specifying the time format (SPICE)
    * @return A formatted string containing the UTC time.
    */

  char tmp[79];
  timout_c(et,FORMAT.c_str(),LENOUT,tmp);
  std::string aux(tmp);
  return aux;

}

std::string et2isod(const double &et)
{
  char tmp[79];
  et2utc_c(et, "ISOD",14,LENOUT,tmp);
  std::string aux(tmp);
  return aux;
}

std::string et2utc(const double &et)
{
  /*! Returns the UTC string corresponding to ephemeris time.
    * @param[in] et Ephemeris time
    * @return A formatted string containing the UTC time.
    * @sa et2str
    */

    return et2str(et, UTC_str);
    // char tmp[79];
    // et2utc_c(et,"C",6,LENOUT,tmp);
    // std::string aux(tmp);
    // return aux;

}

double utc2et(std::string &utc)
{
  /*! Returns the ephemeris time corresponding to a UTC string
    * @param[in] utc A formatted string representing the UTC time.
    * @return Ephemeris time
    * @sa str2et
    */

    return str2et(utc);

}

double jd2mjd( const double &jd )
{
  /*! Returns the modified julian date corresponding to a julian date.
    * @param[in] jd A double containing the julian date.
    * @return The corresponding modified julian date
    */

  return ( jd - (j2000_c()-0.5) );

}

double mjd2jd( const double &mjd )
{
  /*! Returns the modified julian date corresponding to a julian date.
    * @param[in] mjd A double containing the julian date.
    * @return The corresponding modified julian date
    */

  return ( mjd + (j2000_c()-0.5) );

}

double jed2et( const double julianDate )
{
  /*! Convert a Julian date to ephemeris time (equivalent to TDB in Spice).
   * \param[in] julianDate a double for the Julian date.
   * \return et a double for the ephemeris time.
   */

  return ( julianDate - j2000_c() ) * spd_c();

}


double et2jed( const double et )
{
  /*! Convert ephemeris time (equivalent to TDB) to a Julian date.
   * \param[in] et a double for the ephemeris time.
   * \return jed a double for the Julian date.
   */

  return j2000_c() + ( et ) / spd_c();

}

double mjd2et( const double &mjd )
{
  /*! Convert a modfied julian date to ephemeris time (equivalent to TDB in Spice).
   *  \param[in] mjd a double for the modified julian date.
   *  \return et a double for the ephemeris time.
   */

  return (mjd-0.5) * spd_c();

}


double et2mjd( const double et )
{
  /*! Convert ephemeris time (equivalent to TDB) to a modified julian date.
   *  \param et a double for the ephemeris time.
   *  \return mjd a double for the modified julian date.
   */

  return  et / spd_c() + 0.5;

}

/*! @} */ // End of time transformations

/***********************************************************************************
*     Rotation matrix
************************************************************************************/
template<class T>
DACE::AlgebraicMatrix<T> RotationMatrix(const T& angle, const unsigned int &idx )
{
  /*! Returns the \f$ (3 \times 3) \f$ rotation matrix around an axis.
    * @param angle The rotation angle (in radians).
    * @param idx   The ID of the rotation axis.
    * @return An AlgebraicMatrix that can rotate a vector around axis ID of the angle.
    */

    USEDACE_TRIGON

    T cosangle = cos(angle);
    T sinangle = sin(angle);

    DACE::AlgebraicMatrix<T> ROT(3,3,0.);

    switch (idx)
    {
      case 1:
	// Rotation around X axis
	ROT.at(0,0) =  1.;
	ROT.at(1,1) =  cosangle;
	ROT.at(1,2) =  sinangle;
	ROT.at(2,1) = -sinangle;
	ROT.at(2,2) =  cosangle;
	break;

      case 2:
	// Rotation around Y axis
	ROT.at(0,0) =  cosangle;
	ROT.at(0,2) = -sinangle;
	ROT.at(1,1) =  1.;
	ROT.at(2,0) =  sinangle;
	ROT.at(2,2) =  cosangle;
	break;

      case 3:
	// Rotation around Z axis
	ROT.at(0,0) =  cosangle;
	ROT.at(0,1) =  sinangle;
	ROT.at(1,0) = -sinangle;
	ROT.at(1,1) =  cosangle;
	ROT.at(2,2) =  1.;
	break;

    }

    return ROT;

  }


DACE::AlgebraicMatrix<double> TransformationMatrix(const std::string &FROM, const std::string &TO, const double &et)
{
  /*! Computes the transformation matrix from a frame to another.
   * Wrapper of SPICE routine sxform_c.
   * @param FROM Name of the frame to transform from.
   * @param TO   Name of the frame to transform to.
   * @param et   Epoch of the state transformation matrix.
   * @return A \f$ (6\times 6) \f$ state transformation matrix.
   */

  double aux[6][6];
  DACE::AlgebraicMatrix<double> tmp(6,6,0.);

  sxform_c(FROM.c_str(), TO.c_str(), et, aux);


  for (unsigned int i=0; i<6; i++)
    for (unsigned int j=0; j<6; j++)
      tmp.at(i,j) = aux[i][j];

  return tmp;

}


DACE::AlgebraicVector<double> RelativeState(const std::string &TARG, const std::string &REF, const double &et)
{
  /*! Computes the relative state between two celestial bodies.
   * SF wrapper for SPICE routine spkezr_c.
   * The routine returns the position of a target body relative to a reference body at a certain epoch in an equatorial inertial frame (J2000_EQT).
   * @param TARG Name of the target body.
   * @param REF  Name of the reference (observing) body.
   * @param et   Epoch of the state transformation matrix.
   * @return The cartesian state (position and velocity) in J2000_EQT.
   */

  double aux[6];
  double lt;

  spkezr_c(TARG.c_str(), et, FrameNameLabel[J2000_EQT], "NONE", REF.c_str(), aux, &lt);

  DACE::AlgebraicVector<double> tmp(6);

  for (unsigned int i=0; i<6; i++)
    tmp[i] = aux[i];

  return tmp;

}

DACE::AlgebraicVector<double> RelativeState(const std::string &TARG, const Frame F, const double &et)
{
  /*! Computes the relative state between two celestial bodies.
   * SF wrapper for SPICE routine spkezr_c.
   * The routine returns the position of a target body relative to a reference body at a certain epoch in an inertial frame.
   * @param TARG Name of the target body.
   * @param F    Frame structure with frame name and center.
   * @param et   Epoch of the state transformation matrix.
   * @return The cartesian state (position and velocity) in J2000_EQT.
   */

  double aux[6];
  double lt;

  spkezr_c(TARG.c_str(), et,F.getName(),"NONE",F.getOrigin(),aux,&lt);

  DACE::AlgebraicVector<double> tmp(6);

  for (unsigned int i=0; i<6; i++)
    tmp[i] = aux[i];

  return tmp;

}

DACE::AlgebraicVector<double> RelativePosition(const std::string &TARG, const std::string &REF, const double &et)
{
  /*! Computes the relative state between two celestial bodies.
   * SF wrapper for SPICE routine spkezr_c.
   * The routine returns the position of a target body relative to a reference body at a certain epoch in an equatorial inertial frame (J2000_EQT).
   * @param TARG Name of the target body.
   * @param REF  Name of the reference (observing) body.
   * @param et   Epoch of the state transformation matrix.
   * @return The cartesian state (position and velocity) in J2000_EQT.
   */

  double aux[6];
  double lt;

  spkezr_c(TARG.c_str(), et, FrameNameLabel[J2000_EQT], "NONE", REF.c_str(), aux, &lt);

  DACE::AlgebraicVector<double> tmp(3);

  for (unsigned int i=0; i<3; i++)
    tmp[i] = aux[i];

  return tmp;

}

DACE::AlgebraicVector<double> RelativePosition(const std::string &TARG, const Frame F, const double &et)
{
  /*! Computes the relative state between two celestial bodies.
   * SF wrapper for SPICE routine spkezr_c.
   * The routine returns the position of a target body relative to a reference body at a certain epoch in an inertial frame.
   * @param TARG Name of the target body.
   * @param F    Frame structure with frame name and center.
   * @param et   Epoch of the state transformation matrix.
   * @return The cartesian state (position and velocity) in J2000_EQT.
   */

  double aux[6];
  double lt;

  spkezr_c(TARG.c_str(), et,F.getName(),"NONE",F.getOrigin(),aux,&lt);

  DACE::AlgebraicVector<double> tmp(3);

  for (unsigned int i=0; i<3; i++)
    tmp[i] = aux[i];

  return tmp;

}

void pleph(const char* TARGET, double et, const char* FRAME,
		   const char* OBSERVER, const char* ABCORR, DACE::AlgebraicVector<double> &X){
/*! Read JPL ephemeris and return the TARGET body state relative to the OBSERVER body
	at the specified time et and in the given FRAME.
 * \param[in] TARGET a char array with the name of the target body.
 * \param[in] et ephemeris time (equivalent to TDB).
 * \param[in] FRAME a char array with the neme of the frame
 * \param[in] OBSERVER a char array with the name of the observer body
 * (the state computed is given with respect to this body).
 * \param[in] ABCORR a char array with the name of the aberration correction to be applied
    to the state of the target body to account for one-way light time and stellar
    aberration (see spkezr_c function for more details).
 * \param[out] X an AlgebraicVector containing the computed state (output).
 */
	double lt;
	spkezr_c ( TARGET, et, FRAME, ABCORR, OBSERVER, X.data(), &lt );	// XXX: data() is C++11. may not be supported!
}

void pleph(const int TARGET, double et, const char* FRAME,
		   const int OBSERVER, const char* ABCORR, DACE::AlgebraicVector<double> &X){
/*! Read JPL ephemeris and return the TARGET body state relative to the OBSERVER body
	at the specified time et and in the given FRAME.
 * \param[in] TARGET an int with the id code of the target body.
 * \param[in] et ephemeris time (see str2et_c function to convert epoch into et).
 * \param[in] FRAME a char array with the neme of the frame
 * \param[in] OBSERVER an int with the id code of the observer body.
 * (the state computed is given with respect to this body).
 * \param[in] ABCORR a char array with the name of the aberration correction to be applied
    to the state of the target body to account for one-way light time and stellar
    aberration (see spkez_c function for more details).
 * \param[out] X AlgebraicVector containing the computed state (output).
 */
	double lt;
	spkez_c ( TARGET, et, FRAME, ABCORR, OBSERVER, X.data(), &lt );	// XXX: data() is C++11. may not be supported!
}

// static const double ScaleHeight[] = { // follows the order of FrameOrigin in Reference.h
// 	0.0, 0.0, 8500.0, 0.0, 11100.0, 0.0,
// 	0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

// static const double SurfaceDensity[] = { // follows the order of FrameOrigin in Reference.h
// 	0.0, 0.0, 1.217, 0.0, 0.020, 0.0,
// 	0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

template<class T>
T density(const T &rho0, const double &H, const T &h) {
/*! Compute the atmosphere density at the given height above the
 *	body surface. This function is implemented by using an
 * 	exponential model of the form:
 *
 *	rho = rho0 * exp(-h/H)
 *
 *	where rho0 and H are retrieved from here:
 *	http://nssdc.gsfc.nasa.gov/planetary/planetfact.html
 *
 *  \param rho0 a scalar value of type T for the density at the body surface in kg(m^3).
 *  \param H a double for the atmosphere scale height in meters.
 *  \param h a scalar value of type T for the height above the body surface in meters.
 *  \return rho the T value of density in kg/m^3.
 */
	using std::exp;
	//using DACE::exp;

 //    if( (body != EARTH) && (body != MARS) )
 //        throw std::runtime_error("SF::density: Body density not available.");

	// const T rho0 = SurfaceDensity[body];
	// const double H 	= ScaleHeight[body];

// 	T rho = rho0*exp(-1.0*h/H);

	return rho0*exp(-1.0*h/H);
}

template <class T>
T shadow_conical_simple(const DACE::AlgebraicVector<T> &rr_sat, const DACE::AlgebraicVector<double> &rr_sun,  const DACE::AlgebraicVector<double> &rr_B, const double &Radius_B)
{
  using  std::acos;
 // using DACE::acos;
  using  std::asin;
  //using DACE::asin;
  //using DACE::sqr;
  using  std::sqrt;
  //using DACE::sqrt;

  T Q = 0.0;// Biconical/Dual-cone model

  // Get sun radius
  SpiceInt nn; double radii[3];
  bodvrd_c( "SUN", "RADII", 3, &nn, radii );
  double Radius_Sun = (radii[0]+radii[1]+radii[2])/3; // [km] Solar radius

  // Vector sat-occulting body
  DACE::AlgebraicVector<T> s_v = rr_sat - rr_B;
  T s = vnorm(s_v);

  // Vector sun oculting body
  DACE::AlgebraicVector<double> s_sun_v = rr_sun - rr_B;
  double s_sun = vnorm(s_sun_v);

  T beta = acos(dot(s_sun_v,s_v)/(s*s_sun));

  if (DACE::cons(beta)>kPI/2.)
  {
    // Vector sun-sat
    DACE::AlgebraicVector<T> u_v = rr_sun - rr_sat;
    T u = vnorm(u_v);

    // Apparent diameter of the Sun from satellite position
    T a_sun = asin(Radius_Sun/u);

    // Apparent diameter of the occulting body from satellite position
    T a_B = asin(Radius_B/s);

    // Apparent separation of bodies centres
    T c = acos(-dot(s_v,u_v)/(s*u));

    // Shadow condition
    if ((DACE::cons(c)<DACE::cons(a_B)-DACE::cons(a_sun))&&(DACE::cons(a_sun)<DACE::cons(a_B)))
    {
      // Total eclipse
      Q=1.;
    }
    else if ((DACE::cons(c)<DACE::cons(a_sun)-DACE::cons(a_B))&&(DACE::cons(a_sun)>DACE::cons(a_B)))
    {
        // Annular eclipse condition
        Q = DACE::sqr(a_B/a_sun);
    }
    else if ((DACE::cons(c)<DACE::cons(a_sun)+DACE::cons(a_B))&&(DACE::cons(c)>fabs(DACE::cons(a_sun)-DACE::cons(a_B))))
    {
        // Partial eclipse
        T x = (DACE::sqr(c)+DACE::sqr(a_sun)-DACE::sqr(a_B))/(2*c);
        T y = sqrt(DACE::sqr(a_sun)-DACE::sqr(x));

        T A_occ = DACE::sqr(a_sun)*acos(x/a_sun)+DACE::sqr(a_B)*acos((c-x)/a_B)-c*y;

        Q = A_occ/(kPI*DACE::sqr(a_sun));
    }
  }
  return Q;
}

template <class T>
T shadow(const DACE::AlgebraicVector<T> &rr_sat, const DACE::AlgebraicVector<double> &rr_sun,  const DACE::AlgebraicVector<double> &rr_B, const double &Radius_B, const int model_flag=0)
{
  /*! Computes shadow function for occulting body B using shadow model MODEL
   * Computes the shadow function Q for the Sun and the occultating body B
   * Inputs:
   *  \param rr_sat     satellite position in an inertial reference frame
   *  \param rr_sun     sun position in an inertial reference frame
   *  \param rr_B       occultating body position in an inertial reference frame
   *  \param Radius_B   diameter of occultating body (consinstent with other units)
   *  \param model_flag shadow model (optional)
   *                    0 -> Q=0 always (no shadow, default)
   *                    1 -> cylindrical model (Q=0 OR Q=1)
   *                    2 -> biconical model
   *
   * \return the shadow function Q, which represents the percentage of the Sun covered by the occulting body.
   *
   */

  using  std::acos;
 // using DACE::acos;
  using  std::asin;
  //using DACE::asin;
  //using DACE::sqr;
  using  std::sqrt;
  //using DACE::sqrt;

  T Q = 0.0;

  switch (model_flag)
  {
    case(0):
    default:
      break;

    case(1):
    {
      // Cylindrical model
      DACE::AlgebraicVector<double> rr_sat_cons(3);
      for (unsigned int i=0; i<3; i++)
        rr_sat_cons[i] = DACE::cons( (rr_sat[i]) );

      double r_sat_mod = vnorm(rr_sat_cons-rr_B);
      double r_sun_mod = vnorm(rr_sun-rr_B);

      double beta = acos(dot(rr_sat_cons - rr_B,rr_sun - rr_B)/(r_sat_mod*r_sun_mod));

      // Total eclipse check
      if ((beta>kPI/2.)&&(r_sat_mod*std::sin(beta)<Radius_B))
        return 1.0;

      break;
    }

    case(2):
    {
      // Biconical/Dual-cone model (Montenbruck/Gill, Satellite Orbits, pag 80-83)

      // Get sun radius
      SpiceInt nn; double radii[3];
      bodvrd_c( "SUN", "RADII", 3, &nn, radii );
      double Radius_Sun = (radii[0]+radii[1]+radii[2])/3; // [km] Solar radius

      // Vector sat-occulting body
      DACE::AlgebraicVector<T> s_v = rr_sat - rr_B;
      T s = vnorm(s_v);

      // Vector sun-sat
      DACE::AlgebraicVector<T> u_v = rr_sun - rr_sat ;
      T u = vnorm(u_v);

      // Apparent diameter of the Sun from satellite position
      T a_sun = asin(Radius_Sun/u);

      // Apparent diameter of the occulting body from satellite position
      T a_B = asin(Radius_B/s);

      // Apparent separation of bodies centres
      T c = acos(-dot(s_v,u_v)/(s*u));

      if (DACE::cons(c) <= std::abs(DACE::cons(a_B) - DACE::cons(a_sun)))
      {
        if(DACE::cons(a_B) >= DACE::cons(a_sun))
        {
          // Total eclipse
          return 1.0;
        }
        else
        {
          // Annular eclipse
          return DACE::sqr(a_B/a_sun);
        }
      }
      else if(DACE::cons(c) < std::abs(DACE::cons(a_B) + DACE::cons(a_sun)))
      {
        // Partial eclipse
        T x = (DACE::sqr(c)+DACE::sqr(a_sun)-DACE::sqr(a_B))/(2*c);
        T y = sqrt(DACE::sqr(a_sun)-DACE::sqr(x));

        T A_occ = DACE::sqr(a_sun)*acos(x/a_sun)+DACE::sqr(a_B)*acos((c-x)/a_B)-c*y; // Angles might go out of domain here...
        return A_occ/(kPI*DACE::sqr(a_sun));
      }
      break;
    }
  }
  return Q;
}

template<class T>
void position2lla( const DACE::AlgebraicVector<T> &rr_fixed, const Body &body, T &latgd, T &lon, T &alt)
{
  USEDACE_TRIGON
  USEDACE_ALG

  double small_ = 1e-12;
  T magr = vnorm(rr_fixed);

  T c=0.;
  SpiceInt ii;

  // Compute equatorial radius
  double radii[3];
  bodvrd_c( BodyLabel[body], "RADII", 3, &ii, radii );
  double Rearth = radii[0];

  // Compute first eccentricity squared
  double eesqrd = 1. - std::pow(radii[2]/radii[0],2);

  // Compute longitude
  T temp = sqrt( rr_fixed[0]*rr_fixed[0] + rr_fixed[1]*rr_fixed[1] );

  if (fabs(DACE::cons(temp))<small_)
    lon = kPI/2.0*( rr_fixed[2]/fabs( DACE::cons(rr_fixed[2]) ) );
  else
    lon = atan2( rr_fixed[1], rr_fixed[0] );

  if ( fabs(DACE::cons(lon)) >= kPI )
  {
    if ( DACE::cons(lon)< 0.0)
      lon = 2.0*kPI + lon;
    else
      lon = lon - 2.0*kPI;
  }

  // Compute geodetic latitude
  int i = 0;
  latgd = asin(rr_fixed[2]/magr);
  double delta = 10.0;

  while ( ( fabs( delta )>=small_ )&&( i<10 ) )
  {

    delta = DACE::cons(latgd);

    T sintemp = sin(latgd);
    c = Rearth/sqrt(1. - eesqrd*sintemp*sintemp);
    latgd = atan( (rr_fixed[2]+c*eesqrd*sintemp)/temp);

    delta -= DACE::cons(latgd);

    i++;

  }

  // Calculate height
  if (kPI*0.5 - fabs(DACE::cons(latgd)) > kPI/180.0 )
  {
    alt = (temp/cos(latgd)) - c;
  }
  else
  {
    T s = c* (1. - eesqrd);
    alt = rr_fixed[2]/sin(latgd) - s;
  }

  return;

}

// struct planetvar {
// int ID;              // in agreement with spice enumeration (399 = Earth, etc.)
// double ref;
// double H;
// };

// const planetvar plrho[] = {
// {399, 1.217, 8500},  // [kg/m^3, m] see http://nssdc.gsfc.nasa.gov/planetary/factsheet/earthfact.html
// {499, 0.020, 11100}  // [kg/m^3, m] see http://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html
// };

// template<class T>
// T density(const unsigned int id, const T h) {
// /* ! Compute the atmosphere density of the specified body at the given height
//  *	above the planet surface. This function is implemented by using an
//  * 	exponential model of the form:
//  *
//  *	rho = rho0 * exp(-h/H)
//  *
//  *	where rho0 and H are retrieved from here:
//  *	http://nssdc.gsfc.nasa.gov/planetary/planetfact.html
//  *
//  *	\param id Body ID
//  *	\param h height above the planet surface in meters.
//  *  \return rho the T value of density in kg/m^3.
//  */
// 	using std::exp;
// 	using DACE::exp;

//     const int length = sizeof(plrho)/sizeof(planetvar);
// 	int i = 0;
//     for( i=length-1; (i>0)&&(plrho[i].ID != id); i-- );

// 	double rho0 = plrho[i].ref;
// 	double H = plrho[i].H;

// 	T rho = rho0*exp(-1.0*h/H);

// 	return rho;
// }


/*! \defgroup CR3BP CR3BP routines
 * @brief Routines tailored for Circular Restricted 3-Body problem (CR3BP).
 *
 * This module groups all auxiliary routines tailored for the Circular Restricted 3-Body problem.
 * @{
 */

double SynodicMassParameter(const Body &primary, const Body& secondary)
{
  /*! Compute the mass parameter for the restricted three body problem
   * @param[in] primary   primary body ID
   * @param[in] secondary secondary body ID
   * \return the (adimensional) mass parameter
   */

  double GM_1, GM_2;
  SpiceInt n;

  // Retrieve variables from SPICE
  bodvrd_c( BodyLabel[primary], "GM", 1, &n, &GM_1 );
  bodvrd_c( BodyLabel[secondary], "GM", 1, &n, &GM_2 );

  return GM_2/(GM_1+GM_2);

}

void SynodicScaleFactors( const Body &primary, const Body& secondary, const double &et, double &DU, double &TU )
{
  /*! Compute the length and time scale factors for the restricted three body problem
   * @param[in] primary   primary body ID
   * @param[in] secondary secondary body ID
   * @param[in] et        ephemeris time at which scale factors are desired
   * @param[out] DU length scale factor
   * @param[out] TU time scale factor
   * @sa RelativeState
   */

  double GM;
  SpiceInt n;
  bodvrd_c( BodyLabel[primary], "GM", 1, &n, &GM );

  DACE::AlgebraicVector<double> LL = RelativeState(BodyLabel[secondary], BodyLabel[primary], et);

  double elts[8];
  oscelt_c(LL.data(),et,GM,elts);

  DU = elts[0]/(1-elts[1]); // Distance Unit, semi-major axis

  TU = std::sqrt(std::pow(DU,3.)/GM); // Time Unit

}

DACE::AlgebraicVector<double> CR3BPgetSecondaryKeplerianElements( const Body &primary, const Body& secondary, const double &et )
{
  /*! Get the keplerian elements of the secondary body (for CR3BP)
   * The eccentricity of the secondary body is forced to be zero.
   * @param[in] primary   primary body ID
   * @param[in] secondary secondary body ID
   * @param[in] et        ephemeris time at which keplerian elements are desired
   * \return an algebraic vector containing the keplerian elements of the secondary wrt primary body
   * @sa RelativeState
   */

  // Get gravitational parameter from spice kernels
  double GM;
  SpiceInt n;
  bodvrd_c( BodyLabel[primary], "GM", 1, &n, &GM );

  // Define primary inertial reference frame
  Frame Fprimary(J2000_EQT,primary);
  if (primary==SUN)
    Fprimary.Name = J2000_ECL;

  // Obtain position of the seconday wrt to the primary
  DACE::AlgebraicVector<double> LL = RelativeState(BodyLabel[secondary], Fprimary, et);

  // Compute osculating orbital elements
  double elts[8];
  oscelt_c(LL.data(),et,GM,elts);

  // Set orbital elements in AlgebraicVector
  DACE::AlgebraicVector<double> tmp(6);
  tmp[0] = elts[0]/(1-elts[1]); // Semi-major axis
  tmp[1] = 0.0;                 // Eccentricity (circular orbit)
  tmp[2] = elts[2];             // Inclination
  tmp[3] = elts[3];             // Right ascension of the ascending node
  tmp[4] = elts[4];             // Argument of the pericentre

  double E = std::atan2( std::sqrt( (1-elts[1]*elts[1]) )*std::sin(elts[5])/(1+elts[1]*std::cos(elts[5])),
		    (elts[1]+std::cos(elts[5]))/( 1+elts[1]*std::cos(elts[5]) ) );
  if (E<0)
    E += 2*kPI;
  tmp[5] = E - elts[1]*std::sin(E);  // Mean/true anomaly (circular orbit)

  return tmp;

}

/*! @} */ // End of CR3BP module

DACE::AlgebraicVector<double> SPICEpropagate( const DACE::AlgebraicVector<double> &KE, const Body &attractor, const double &et0, const double &etf )
{
  /*! Propagate keplerian elements using SPICE routine conics_c.
   * @param[in] KE        keplerian elements vector
   * @param[in] attractor attractor body ID
   * @param[in] et0       ephemeris time corresponding to initial epoch
   * @param[in] etf       ephemeris time corresponding to final epoch
   * \return an algebraic vector containing the keplerian elements of the secondary wrt primary body
   */

  // Obtain gravitational parameter of primary
  double GM;
  SpiceInt n;
  bodvrd_c( BodyLabel[attractor], "GM", 1, &n, &GM );

  double elts[8];
  elts[0] = KE[0];  // Semi-major axis == pericentre (circular)
  elts[1] = KE[1];  // Eccentricity
  elts[2] = KE[2];  // Inclination
  elts[3] = KE[3];  // Right ascension of the ascending node
  elts[4] = KE[4];  // Argument of the pericentre
  elts[5] = KE[5];  // Mean anomaly
  elts[6] = et0;    // Epoch of orbital elements
  elts[7] = GM;     // Gravitational parameter

  double state[6];
  conics_c(elts,etf,state);

  DACE::AlgebraicVector<double> tmp(6);
  tmp[0] = state[0];
  tmp[1] = state[1];
  tmp[2] = state[2];
  tmp[3] = state[3];
  tmp[4] = state[4];
  tmp[5] = state[5];

  return tmp;

}

double KeplerEquation(double ecc, double M, double tol=1e-12)
{
  /*! Solve Kepler's equation for eccentric anomaly.
   * @param[in] ecc orbit eccentricity
   * @param[in] M   mean anomaly [rad]
   * @param[in] tol tolerance to stop iterations
   * @return the eccentric anomaly in radians.
   *
   * Kepler equation is here defined as \f$E-e\sin{E}=M\f$ and is solved using a Newton's method.
   */
  int maxiter=30;

  // Compute mean anomaly
  M = fmod(M, 2.*kPI);

  // Initialize eccentric anomaly
  double E = M;

  // Write Kepler implicit equation
  double F = E - ecc*std::sin(E) - M;

  // Iterate with Newton's method
  int i=0;
  while((std::abs(F)>tol)&&(i<maxiter))
  {
    E = E - F/(1.0-ecc*std::cos(E));
    F = E - ecc*std::sin(E) - M;
    i++;
  }

  return E;
}

double KeplerEquation(double sma, double ecc, double deltaT, double GM, double tol=1e-12)
{
  /*! Solve Kepler's equation for eccentric anomaly.
   * @param[in] sma     semi major axis [km]
   * @param[in] ecc     orbit eccentricity
   * @param[in] deltaT  time since reference epoch
   * @param[in] GM      gravitational parameter [km^3/s^2]
   * @param[in] tol     tolerance to stop iterations
   * @return the eccentric anomaly in radians.
   *
   * Kepler equation is here defined as \f$E-e\sin{E}=\sqrt{\frac{GM}{a^3}}(t-t_0)\f$ and is solved using a Newton's method.
   */

  // Compute mean anomaly
  double M = (std::sqrt(GM/sma)/sma)*deltaT;

  return KeplerEquation(ecc,M,tol);

}

template<typename T>
T tofabn(T sigma, T alpha, T beta)
{
  /*! Function that evaluates the time of flight via Lagrange expression
   *
   */

  using std::sin;
  using std::sqrt;
//  using DACE::sin;
//  using DACE::sqrt;
  using std::log;
//  using DACE::log;
  using std::sinh;
//  using DACE::sinh;

   if (DACE::cons(sigma)>0)
      return sigma*sqrt(sigma)*((alpha-sin(alpha))-(beta-sin(beta)));
   else
      return -sigma*sqrt(-sigma)*((sinh(alpha)-alpha)-(sinh(beta)-beta));
}

template<typename T>
T x2tof(const T &x, const T &s, const T &c, int lw)
{

  using  std::asin;
//  using DACE::asin;
//  using DACE::acos;
  using  std::acos;

  using  std::sqrt;
//  using DACE::sqrt;
  using std::log;
//  using DACE::log;


  T alpha, beta;

  T a = (s/2.)/(1.-x*x);

  if (DACE::cons(x)<1.)
  {
    // Ellipse
    beta = 2*asin(sqrt((s-c)/2./a));
    if (lw==1)
      beta = -beta;

    alpha = 2.*acos(x);

  }
  else
  {
    alpha = 2.*log(x+sqrt(x*x-1.));
    T aux = sqrt((s-c)/(-2.*a));

    beta = 2.*log(aux+sqrt(aux*aux+1.));
    if (lw==1)
      beta = -beta;

  }

  return tofabn(a,alpha,beta);

}

}

#endif /* astro_AstroRoutines_H */
